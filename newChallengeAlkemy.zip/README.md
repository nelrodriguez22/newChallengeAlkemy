# Alkemy Challenge App

App realizada para aplicar a la aceleracion de diciembre de Alkemy.

### `Superheroes App`

Esta aplicacion se utiliza para armar un equipo de heroes, los cuales se mostraran con sus
respectivas estadisticas y promedios .
Pero cuidado! Existen algunas condiciones para la creacion de los mismos. Estos se conformaran 
de un maximo de 6 heroes, deberan tener un maximo de 3 heroes con alineacion buena y  3 heroes
con alineacion mala. No te preocupes demasiado por recordar estas reglas ya que la app se 
encargara de chequearlo por ti. Espero que la disfrutes tanto como yo disfrute de realizarla.




`by unlimitD`