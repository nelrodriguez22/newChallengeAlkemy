

//login Types
export const types = {
	login: '[auth] login',
	logout: '[auth] logout'
}

//teambuilder types
export const tbtypes ={
	add_hero :'[tb] add_hero',
	rmv_hero: '[tb] rmv_hero'
}


